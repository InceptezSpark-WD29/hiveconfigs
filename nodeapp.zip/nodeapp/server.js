var express = require('express');
var app = express();
var path = require('path');
const bodyParser = require('body-parser');
const mysql = require('mysql');
var cassandra = require("cassandra-driver"); 


//create mysql database connection
const conn = mysql.createConnection({
  host: 'localhost',
  user: 'hduser',
  password: 'hduser',
  database: 'troubleticketdb'
});
 
//connect to mysql  database
conn.connect((err) =>{
  if(err) throw err;
  console.log('Mysql Connected...');
});

// cassandra database config
var dbConfig = {
	contactPoints : ['localhost'],
	localDataCenter: 'datacenter1',
	keyspace:'trbltktdb'
};

var cassandracon = new cassandra.Client(dbConfig);
cassandracon.connect(function(err,result){
	console.log('cassandra connected');
});

app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, 'public')));
//app.use(express.static('public'))

app.get('/', function(req, res) {
     res.sendFile(path.join(__dirname + '/index.html'))
});

app.get('/dashboard', function(req, res) {
     res.sendFile(path.join(__dirname + '/dashboard.html'))
});

app.get('/transaction', function(req, res) {
     res.sendFile(path.join(__dirname + '/transaction.html'))
});

app.get('/managetickets', function(req, res) {
     res.sendFile(path.join(__dirname + '/managetickets.html'))
});



//get data
app.get('/api/getchannelcount',(req, res) => {
  let sql = "select channel,count(*) as ticketcount from tbltroubleticket group by channel";
  let query = conn.query(sql, (err, results) => {
    var tickcnt = [];
    var channel = [];
    if(err) throw err;
      Object.keys(results).forEach(function(key) {
      var row = results[key];
      tickcnt.push(row.ticketcount);
      channel.push(row.channel);
    });
    console.log(tickcnt);

    res.send({"status": 200, "error": null, "data_xaxis": channel, "data_yaxis": tickcnt});
  });
});


app.get('/api/getmetrics',(req, res) => {
  let sql1 = "select count(*) ticketcount from tbltroubleticket";
  let sql2 = "select `call` as callcnt,email as emailcnt,`mobile-app` as mobilecnt,web as webcnt  from tblchannelmetrics where created_on=current_date()";
  totaltickets = 0
  todaytickets = 0
  let query = conn.query(sql1, (err, results) => {
    if(err) throw err;
	console.log(results)
        totaltickets = results[0].ticketcount;
	query = conn.query(sql2, (err, results) => {
    		if(err) throw err;
			console.log(results)
        		callcnt = results[0].callcnt;
			emailcnt = results[0].emailcnt;
			mobilecnt = results[0].mobilecnt;
			webcnt = results[0].webcnt;	
			res.send({"status": 200, "error": null, "ticketcount": totaltickets,"callcnt": callcnt,"webcnt":webcnt,"mobilecnt":mobilecnt,"emailcnt":emailcnt});
		
  	});
	
  });
  
});

app.post('/api/saveticket',(req, res) => 
{
  console.log(req.body);
  var str = req.body.msg;
  var strdata = str.split("#")
  var channel = strdata[0]
  var priority = strdata[1]
  var calltype = strdata[2]
  var custid = strdata[3]
  var category = strdata[4]
  var subcategory = strdata[5]
  var agentid = strdata[6]
  var sql = "insert into tbltroubleticket(channel,calltype,agent_id,priority,cust_id,service_category,service_subcategory,service_id,tkt_status,resolve_status,created_on,updated_on) values('" + channel + "','" + calltype +"','"+ agentid +"','"+ priority +"','"+ custid +"','"+ category +"','" + subcategory +"','NA','open','pending',current_date(),current_date())"
  console.log(strdata);
  
  let query = conn.query(sql, (err, results) => {
    if(err) throw err;
	console.log(results.insertId);
    	res.send({"status": 200, "error": null, "result": results.insertId});
  });  
});

app.post('/api/savetroubleticket',(req, res) => 
{
  console.log(req.body);
  var str = req.body.msg;
  var strdata = str.split("#")
  var troubleticketid = Math.floor(Date.now()/1000);
  var channel = strdata[0]
  var priority = strdata[1]
  var calltype = strdata[2]
  var custid = strdata[3]
  var category = strdata[4]
  var subcategory = strdata[5]
  var agentid = strdata[6]
  var todayDate = new Date().toISOString().slice(0, 10);
  console.log(todayDate);
  var createdon = todayDate;
  var updatedon = todayDate;
  var sql = "insert into tbltroubleticket(trbl_tkt_id,channel,calltype,agent_id,priority,cust_id,service_category,service_subcategory,service_id,tkt_status,resolve_status,created_on,updated_on) values(?,?,?,?,?,?,?,?,'NA','open','pending',?,?)"
  console.log(strdata);
  var params = [troubleticketid,channel,calltype,agentid,priority,custid,category,subcategory,createdon,updatedon];
  let query = cassandracon.execute(sql,params,(err, results) => {
    if(err) throw err;
	console.log(results.insertId);
    	res.send({"status": 200, "error": null, "result": results});
  });  
});

//get all trouble tickets
app.get('/api/getalltroubletickets',(req, res) => {
  let sql = "select * from tbltroubleticket";
  let query = cassandracon.execute(sql, (err, results) => {
    if(err) throw err;
   	 console.log(results);
    	res.send({"data":results.rows});
  });
});

app.listen(3001);
