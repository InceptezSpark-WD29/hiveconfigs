var cassandra = require("cassandra-driver"); 
var express  = require('express');
var router = express.Router();

// cassandra database config
var dbConfig = {
	contactPoints : ['localhost'],
	keyspace:'trbltktdb'
};

var connection = new cassandra.Client(dbConfig);

connection.connect(function(err,result){
	console.log('cassandra connected');
});

router.get('/gettrbltickets', function(req,res){
	var data = {
		"trbl_tkt_id":1,
		"agent_id":""
	};
	var select = "select * from tbltroubleticket";
	connection.execute(select,function(err, rows){
		if (rows.length != 0) {
			data["error"] = 0;
			data["Books"] = rows;
			res.json(data);
		}else{
			data["Books"] = "No books Found..";
			res.json(data);
		}
	});
});

