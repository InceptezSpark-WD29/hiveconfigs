$(document).ready(function(){
	
	 var dtable = $('#tbltrbltkt').DataTable({
        "ajax": "/api/getalltroubletickets",
        "columns": [
            { "data": "trbl_tkt_id" },
            { "data": "calltype" },
            { "data": "channel" },
            { "data": "resolve_status" },
            { "data": "service_category" },
            { "data": "priority" },
 	    { "data": "updated_on" },
	    { "data": "action" ,
		"render": function ( data) {
		return '<a href="#" class="edit"><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></a><a href="#deleteEmployeeModal" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a>';}
	    }
        ]
    } );

   $("#btnaddtkt").click(function(){
	if($.trim($("#ddlchannel").val()) == "")
	{
		$("#lblmsg").html("Select Channel");
		$("#ddlvendor").focus();
	}
	else if($.trim($("#ddlcalltype").val()) == "")
	{
	     $("#lblmsg").html("Select Call Type");
	     $("#ddlcalltype").focus();
	}
	else if($.trim($("#txtcustid").val()) == "")
	{
		$("#lblmsg").html("Enter Customer Id");
		$("#txtcustid").focus();
	}
	else if($.trim($("#ddlsvccat").val()) == "")
	{
	     $("#lblmsg").html("Select Service Category");
	     $("#ddlsvccat").focus();
	}
	else if($.trim($("#ddlagent").val()) == "")
	{
	     $("#lblmsg").html("Select AgentId");
	     $("#ddlagent").focus();
	}
	else if($.trim($("#txtsvcsubcat").val()) == "")
	{
		$("#lblmsg").html("Enter Problem Description");
		$("#txtsvcsubcat").focus();
	}

	else
        {

		var strdata = $("#ddlchannel").val() + "#low#" + 
		$("#ddlcalltype").val() + "#" + $("#txtcustid").val() + "#" + $("#ddlsvccat").val() + "#" + $("#txtsvcsubcat").val() + "#" + 			$("#ddlagent").val();
		$.ajax({
                type: "POST",
                url: '/api/savetroubleticket',               
                dataType: "json",
		data: {msg:strdata},
                success: function (response) 
		{
		    alert("Ticket Created..");
		    $("#ddlchannel").val("");
		    $("#ddlcalltype").val("");	
		    $("#txtcustid").val("");
		    $("#ddlsvccat").val("");	
		    $("#txtsvcsubcat").val("");
		    $("#ddlagent").val("");
		    $("#mdladdticket").modal('toggle');
		    $('#tbltrbltkt').DataTable().ajax.reload()
                }
            	});

		
	}
    });

    $('#tbltrbltkt tbody').on('click', '.edit', function () {
	var data = dtable.row($(this).closest('tr')).data();
	$("#txtetktid").val(data["trbl_tkt_id"]);
	$("#ddlechannel").val(data["channel"]);
	$("#ddlecalltype").val(data["calltype"]);
	$("#txtecustid").val(data["cust_id"]);
	$("#ddlesvccat").val(data["service_category"]);
	$("#txtesvcsubcat").val(data["service_subcategory"]);
	$("#ddleagent").val(data["agent_id"]);
 	$("#mdleditticket").modal('toggle');
    });
    

});
